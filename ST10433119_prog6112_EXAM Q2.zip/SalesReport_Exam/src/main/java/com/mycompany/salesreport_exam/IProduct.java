
package com.mycompany.salesreport_exam;


public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductsSold();
    String GetMostPopular();
    
    
}
