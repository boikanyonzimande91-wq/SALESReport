

package com.mycompany.salesreport_exam;

import java.util.Scanner;


public class SalesReport_Exam {

    public static void main(String[] args) {
        SalesReport SalesReport = new SalesReport();
        
        Scanner scanner = new Scanner(System.in);

        // Single-dimensional array for the three top-performing products
        String[] products = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        // Two-dimensional array: 3 products (rows) x 3 months (columns)
        int[][] sales = new int[3][3];

        // 1. Capture user input for each product over 3 months
        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter number of sales for month " + (j + 1) + " for " + products[i] + ": ");
                sales[i][j] = scanner.nextInt();
            }
            System.out.println(); // Blank line between products to match screenshot
        }

        // 2. Calculate total sales, average, and find the highest single sale
        int totalSales = 0;
        int totalEntries = 0;
        int maxSale = sales[0][0];
        String mostPopularProduct = products[0];

        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                totalSales += sales[i][j];
                totalEntries++;

                if (sales[i][j] > maxSale) {
                    maxSale = sales[i][j];
                    mostPopularProduct = products[i];
                }
            }
        }

        // Calculate average across all entries (153 / 9 = 17)
        int averageSales = totalSales / totalEntries;

        // Clean up the product name for the final line (removes " mattress" to match sample output)
        String formattedProductName = mostPopularProduct.replace(" mattress", "");

        // 3. Display the formatted report
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("*********************************************");
        System.out.println("TOTAL PRODUCT SALES: " + totalSales);
        System.out.println("AVERAGE PRODUCT SALES: " + averageSales);
        System.out.println("MOST POPULAR PRODUCT: " + formattedProductName + " (" + maxSale + ")");

        scanner.close();
    }
}
    

